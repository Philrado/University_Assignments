import sqlite3 
from sqlite3 import Error
import bcrypt


db_file = 'greyhound.db'

def create_connection():

    conn = None
    global db_file
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
        

    return conn 


def insert_user(conn, user_name, user_email, user_password, table_name="users"):

    values = (user_name, user_email, user_password)
    sql_command = """INSERT INTO {}(name, email, password) VALUES (?,?,?) """.format(table_name)

    c = conn.cursor()
    c.execute(sql_command, values)
    conn.commit()


def get_password(conn, email, table_name="users"):

    value = (email,)
    sql_command = """ SELECT password FROM {} WHERE email = ?""".format(table_name)

    c = conn.cursor()
    c.execute(sql_command, value)

    return c.fetchall()[0][0]

def insert_schedule(conn, fromCity, toCity, depart_date, depart_time, arrive_date, arrive_time, numSeats, price, table_name="schedules"):
    values = (fromCity, toCity, depart_date , depart_time, arrive_date , arrive_time, numSeats, price)
    sql_command = """INSERT INTO {}(fromCity, toCity, depart_date, depart_time, arrive_date, arrive_time, seats, price) VALUES (?,?,?,?,?,?,?,?) """.format(table_name)
    c = conn.cursor()
    c.execute(sql_command, values)
    conn.commit()


# conn = create_connection()

# create_users_table(conn)
# user_name = "timal"
# user_email = "tperamun@uwo.ca"
# user_password = "password"

# salt = bcrypt.gensalt()

# hashed = bcrypt.hashpw(user_password.encode('utf-8'), salt)

# insert_user(conn, user_name, user_email, hashed.decode("utf-8"))

# password = get_password(conn, user_email)

# print(password)
# print(type(password))