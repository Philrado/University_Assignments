from greyhound.backend.sqlite_operations import login
import bcrypt

class User:

    salt = bcrypt.gensalt()

    def __init__(self, name, email, password):
        self._name = name
        self._email = email       
        self._hashed_password = bcrypt.hashpw(password.encode(), salt)

    def get_name(self):
        return self._name
    
    def get_email(self):
        return self._email

    def get_hashed_password(self):
        return self._hashed_password


