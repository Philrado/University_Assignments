# Script to create all tables
import sqlite3
from sqlite3 import Error
import sqlite_operations

def create_connection(db_file):

    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
        

    return conn 

def create_table(conn, table_name):

    sql_command = """ CREATE TABLE IF NOT EXISTS {} (name text, email text, password text) """.format(table_name)
    schedule_command = """ CREATE TABLE IF NOT EXISTS {} (fromCity text, toCity text, depart_date date, depart_time time, arrive_date date, arrive_time time, seats number, price number) """.format("schedules")

    c = conn.cursor()
    c.execute(sql_command)
    c.execute(schedule_command)
    conn.commit()

# Create tables

def create_schedules(conn, table_name):
    f = open('schedules.txt')
    schedules = f.read().split("\n")
    f.close() 
    for schedule in schedules:
        scheduleList = schedule.split()
        sqlite_operations.insert_schedule(conn, *scheduleList)


conn = create_connection("greyhound.db")
create_table(conn, "users")

#Only create schedules Once.. if everything wiped, uncomment below
# create_schedules(conn, "schedules") 



