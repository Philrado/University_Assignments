import sqlite_operations

from flask import Flask, request, render_template, redirect, flash
import json, bcrypt
import smtplib


app = Flask(__name__, static_url_path='/static')
app.config['SECRET_KEY'] = '74c14f079360cf448b625f666d5651a'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/signin_page')
def signin_page():
    return render_template('signin.html')

@app.route('/register_page')
def register_page():
    return render_template('register.html')

@app.route('/signin', methods=['POST'])
def signin():
    user_email = request.form['email']
    user_password = request.form['password']
    conn = sqlite_operations.create_connection()
    hashed_password = sqlite_operations.get_password(conn, user_email, table_name="users")

    salt  = hashed_password[:29].encode('utf-8')
    encoded_password = hashed_password[29:].encode('utf-8')

    hashed_pass = bcrypt.hashpw(encoded_password, salt)
    
    user_password_encoded = bcrypt.hashpw(user_password.encode('utf-8'), salt)
    
    if bcrypt.checkpw(user_password_encoded, hashed_pass):
        #Match found
        return render_template('index2.html', email=user_email)
    else:
        flash(f'Login Unsuccessful. Please check email and password.', 'danger')
        return render_template('signin.html')


@app.route('/register', methods=['POST'])
def register_user(): 
    
    user_name = request.form['name']
    user_email = request.form['email']
    user_password = request.form['password']

    # print(user_email, user_email, user_password)
    

    conn = sqlite_operations.create_connection()
    salt = bcrypt.gensalt()


    hashed_password = bcrypt.hashpw(user_password.encode('utf-8'), salt) #returns bytes string. SO u have to decode it to a string
    hashed_password_decoded = hashed_password.decode('utf-8')
    salt_decoded = salt.decode('utf-8')

    # Length of salt_decoded is 29
    # Length of hashed_password_decoded is 60

    # so when checking for the password, we can split the password accordingly to get the salt and the password
    storage_password = salt_decoded + hashed_password_decoded
    sqlite_operations.insert_user(conn, user_name, user_email, storage_password)

    return redirect('/')

@app.route('/book_trip', methods=['POST'])
def book_trip(): 
    fromCity = request.form['fromCity'].lower()
    toCity = request.form['toCity'].lower()
    depart_date = request.form['depart']
    numAdult = request.form['adult']
    numChildren = request.form['children']
    numSenior = request.form['senior']
    if not numAdult:
        numAdult = 0
    if not numChildren:
        numChildren = 0
    if not numSenior:
        numSenior = 0
    depart_date_before = depart_date[:-2] + "{0:0=2d}".format(int(depart_date[-2:]) - 1)
    depart_date_after = depart_date[:-2] + "{0:0=2d}".format(int(depart_date[-2:]) + 1)

    values = (fromCity, toCity, depart_date)

    conn = sqlite_operations.create_connection()
    c = conn.cursor()

    c.execute("SELECT * FROM schedules WHERE fromCity=? AND toCity=? AND depart_date=?", values)
    dates = c.fetchall()


    return render_template('/schedule.html',fromCity=fromCity, depart_date_before=depart_date_before, depart_date_after=depart_date_after, toCity=toCity, depart=depart_date, adult=numAdult, children=numChildren, senior=numSenior, dates=dates)

@app.route('/pick_schedule/<schedule>/<numAdult>/<numChildren>/<numSenior>')
def pick_schedule(schedule,numAdult,numChildren,numSenior):
    numAdult, numChildren, numSenior = int(numAdult), int(numChildren), int(numSenior)
    scheduleList = eval(schedule)
    price = int(scheduleList[-1])
    totalPrice = (price * numAdult) + (price*0.75 * numSenior) + (price*0.5 * numChildren)
    priceAfterTax = str("$%.2f" % (totalPrice * 1.13))
    totalPrice = str("$%.2f" % totalPrice)
    scheduleList = eval(schedule)
    return render_template('/payment_nologin.html', schedule=scheduleList, fromCity=scheduleList[0], toCity=scheduleList[1], date=scheduleList[2], depart_time=scheduleList[3], arrive_time=scheduleList[5], numAdult=numAdult, numChildren=numChildren, numSenior=numSenior, priceAfterTax=priceAfterTax, totalPrice=totalPrice)

@app.route('/payment/<schedule>/<numAdult>/<numChildren>/<numSenior>', methods=['POST'])
def payment(schedule,numAdult,numChildren,numSenior):
    numAdult, numChildren, numSenior = int(numAdult), int(numChildren), int(numSenior)
    scheduleList = eval(schedule)
    price = int(scheduleList[-1])
    totalPrice = (price * numAdult) + (price*0.75 * numSenior) + (price*0.5 * numChildren)
    priceAfterTax = str("$%.2f" % (totalPrice * 1.13))
    totalPrice = str("$%.2f" % totalPrice)
    firstName = request.form['firstName']
    lastName = request.form['lastName'] 
    email = request.form['email']
    #Do payment stuff here and send email
    sender_email = "greyhound4474Project@gmail.com"
    rec_email = str(email)
    password = "passwordisamazing123"

    message = "Hey, thanks for using Greyhound!\nYour bus is from %s to %s will leave on %s at %s and will arrive on %s at %s\nThe price is %s and the total after tax is %s\nMake sure you show up 30 minutes before!" % (scheduleList[0].capitalize(), scheduleList[1].capitalize(),scheduleList[2], scheduleList[3], scheduleList[4], scheduleList[5], totalPrice, priceAfterTax)
    subject = "Greyhound Bus Ticket Confirmation"
    message = 'Subject: {}\n\n{}'.format(subject, message)
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, rec_email, message)


    return render_template('/payment_confirmed.html', schedule=schedule, firstName=firstName, lastName=lastName, email=email, totalPrice=totalPrice, priceAfterTax=priceAfterTax)

if __name__== '__main__':
    app.run("127.0.0.1", port=5002, debug=True)
