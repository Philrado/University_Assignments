python3 create_tables.py && python3 app.py
