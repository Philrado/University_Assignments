Hello, and welcome to my game, "Rescripted Return".
___________________________________________________


How to Install the game:
------------------------
Install Unity.
Then specifically install Unity 2018.4.17f1 (64-bit).


How to execute the game:
------------------------
CLick on the executable within the files given to you, called "Rescripted Return".


How to play it:
---------------

Once you click play, you can read the control instructions, 
and explore the small bit of gameplay and platforming available.


The features I have completed:
------------------------------

Art:
	Currently all graphics are original art made by me as placeholders 
	while I hand draw and electronically design better art for the future.

Movement:
	My character can move left, right, and jump.
Platforming:
	Currently there are 2 types of platforms, fully solid, and ones you can jump through from the bottom.

Combat:
	Currently my character can attack, and deal damage to enemies with health.
	However enemies cannot attack back.
UI:
	I have created a menu and control screen for the game with proper scene management.


Note:
-----

Unfortunately I was unable to make a restart button currently, so the only way to restart the level is to exit the game manually
through control-alt-delete or alt-f4, or just tabbing out, right clicking the game icon and clicking quit.

So if you fall off the map you will need to restart, and if you kill the enemy you will need to restart if you want them 
to respawn.

I'm sorry for the inconvenience. Thank you.