Hello, I have left the older version of my assignment so you can see I tried to put comments, but realized "last minute" that I would have to comment very differently, so I removed them all. Sorry about the disorganization, with my street power making me lose half my assignment, and working through 2 other assignments and a fever, it's been hectic.


I can let you know right now now, in the main class of my program, there are 9 points (1 for each bullet point).

1.) List The Doctors					-	Works

2.) List of Doctors Licensed Before a Given Date		-	Works

3.) Add a Doctor 					- 	Button Fails

4.) Delete a Doctor					-	Works

5.) Update the Name of a Hospital			-	Button Fails

6.) List for Hospital and Head Doctor Information		-	Works

7.) Find a Patient (Using their OHIP Number)		-	Button Fails

8-a.) Assign Treatment (Choose a Doctor to Treat a Patient)	-	Works

8-b.) Stop a Doctor From Treating a Patient		-	Works
		
9.) List of Available Doctor's with No Patients		-	Works