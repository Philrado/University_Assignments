
<?php
   echo "Please select the ordering option you would prefer to see the list in: </br>";
   echo "</br>";
   echo '<input type = "radio" name = "order" value = "fname" checked> Ascending First Name<br>'; 
   echo '<input type = "radio" name = "order" value = "fname DESC" checked> Descending First Name<br>';
   echo '<input type = "radio" name = "order" value = "lname" checked> Ascending Last Name<br>';
   echo '<input type = "radio" name = "order" value = "lname DESC" checked> Descending Last Lame<br>';
?>
